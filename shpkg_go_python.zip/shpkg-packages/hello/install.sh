#!/bin/bash
echo "Installing hello package..."
python3 shpkg-packages/hello/hello.py
