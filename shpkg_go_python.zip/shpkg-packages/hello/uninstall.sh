#!/bin/bash
echo "Uninstalling hello package..."
echo "Nothing to remove for this demo."
